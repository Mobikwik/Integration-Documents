<?php 

class Zaakpay_Model_Api_Update extends Varien_Object 
{

    public static $UPDATE_ENDPOINT = 'https://api.zaakpay.com/updatetransaction';
	public static $CHECK_ENDPOINT = 'https://api.zaakpay.com/checktransaction';

    public static $STATUS_CANCELLED = '8';

    public static $STATUS_REFUNDED = '14';

    public static $STATUS_SETTLED = '7';

    public static $CANCELLED_RESP_CODES = array(226, 198);
    
    public function send($orderId, $updateDesired, $updateReason) 
    {
       $request_new = Mage::getModel('zaakpay/api_request');
        $request_new->setZaakpayConfig(Mage::getStoreConfig('payment/zaakpay'))
            ->setUrl(self::$CHECK_ENDPOINT)
            ->addParam('orderId', $orderId)
            ->send();
        $response = $request_new->getResponseCode();
        //***********************************************************//
		if($response == 233)
		{
		$updateDesired = 14;
		}
		else
		{
		$updateDesired = 8;
		}
		
		//***********************************************************//
	 
        // unset the statuscache 
        $session = Mage::getSingleton('zaakpay/session');
        $session->clearStatusCache();

    }
}

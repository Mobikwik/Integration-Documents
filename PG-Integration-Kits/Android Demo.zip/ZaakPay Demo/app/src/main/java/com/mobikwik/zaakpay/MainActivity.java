package com.mobikwik.zaakpay;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.mobikwik.mobikwikpglib.PaymentCheckout;
import com.mobikwik.mobikwikpglib.activities.MobiKwikPGLibActivity;
import com.mobikwik.mobikwikpglib.lib.transactional.TransactionData;
import com.mobikwik.mobikwikpglib.lib.transactional.TransactionDataBuilder;
import com.mobikwik.mobikwikpglib.lib.transactional.TransactionResponse;
import com.mobikwik.mobikwikpglib.utils.Enums;
import com.mobikwik.mobikwikpglib.utils.Utils;
import com.mobikwik.zaakpay.databinding.ActivityMainBinding;

import org.jetbrains.annotations.NotNull;

import java.math.BigInteger;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends AppCompatActivity implements PaymentCheckout.ZaakPayPaymentListener {

    private ActivityMainBinding binding;
    private String checksumTransact;
    private String checksumPO;
    private static String TAG = "Demo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        binding.btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setCheckSums();
                TransactionData transactionData = buildViaDynamicParams();
                PaymentCheckout paymentCheckout = new PaymentCheckout(MainActivity.this);
                paymentCheckout.startPayment(transactionData);

            }
        });

    }

    private TransactionData buildViaDynamicParams() {
        TransactionDataBuilder transactionDataBuilder = TransactionDataBuilder.TransactionDataBuilder()
                .withAmount(new BigInteger(binding.editTextAmount.getText().toString()))
                .withChecksum(checksumTransact)
                .withChecksumPO(checksumPO)
                .withCurrency("INR")
                .withOrderId(binding.editTextOrderid.getText().toString())
                .withUserEmail(binding.editTextEmail.getText().toString())
                .withReturnUrl(binding.editTextReturnUrl.getText().toString())
                .withMerchantIconUrl(binding.editTextMerchantIcon.getText().toString())
                .withMerchantName(binding.editTextMerchantName.getText().toString())
                .withMerchantId(binding.editTextMerchantId.getText().toString())
                .withUserPhoneNumber(binding.editTextPhone.getText().toString())
                .withEnvironment(Enums.Environment.TESTING);


        return transactionDataBuilder.build();
    }

    private void showAlertDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Transaction Response");
        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    private void setCheckSums() {

        String ip = Utils.getLocalIpAddress();
        String date = Utils.getCurrentDate();


        String paramsForTransactChecksum = "'" + binding.editTextMerchantId.getText().toString() + "''" +
                binding.editTextOrderid.getText().toString() + "''0''INR''" + binding.editTextAmount.getText().toString() +
                "''" + ip + "''" + date + "'";

        Log.d(TAG, paramsForTransactChecksum);

        String paramsForPOChecksum = "merchantIdentifier=" + binding.editTextMerchantId.getText().toString() + "&email=" + binding.editTextEmail.getText().toString();

        String secretKey = "0678056d96914a8583fb518caf42828a";

        try {
            checksumTransact = createChecksum(secretKey, paramsForTransactChecksum);

            checksumPO = createChecksum(secretKey, paramsForPOChecksum);


            binding.editTextChecksum.setText(checksumTransact);
            binding.editTextChecksumPo.setText(checksumPO);

        } catch (Exception ex) {
            Log.d(TAG, "checksum exception");
        }
    }

    public static String createChecksum(String secretKey, String allParamValueExceptChecksum) throws Exception {
        Log.d(TAG, "In cryptoUtils createChecksum function");
        byte[] dataToEncryptByte = allParamValueExceptChecksum.trim().getBytes();
        SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(secretKeySpec);
        byte[] checksumCalculatedByte = mac.doFinal(dataToEncryptByte);
        return toHex(checksumCalculatedByte);
    }

    private static String toHex(byte[] bytes) {
        StringBuilder buffer = new StringBuilder(bytes.length * 2);
        String str;
        for (Byte b : bytes) {
            str = Integer.toHexString(b);
            int len = str.length();
            if (len == 8) {
                buffer.append(str.substring(6));
            } else if (str.length() == 2) {
                buffer.append(str);
            } else {
                buffer.append("0" + str);
            }
        }
        return buffer.toString();
    }

    @Override
    public void onPaymentFailure(@NotNull String responseCode, @NotNull String responseMsg) {

        String sb = ("\nStatus Code : " + responseCode) +
                "\nStatus Message : " + responseMsg;
        showAlertDialog(sb);
    }

    @Override
    public void onPaymentSuccess(@NotNull TransactionResponse transactionResponse) {

        String sb = ("\nStatus Code : " + transactionResponse.getResponseCode()) +
                "\nStatus Message : " + transactionResponse.getResponseDescription();
        showAlertDialog("Payment Success " + sb);
    }
}

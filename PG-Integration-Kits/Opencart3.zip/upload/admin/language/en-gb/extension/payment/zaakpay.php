<?php

$_['heading_title']      = 'MobikwikPG';

$_['text_payment']       = 'Payment';
$_['text_extension']     = 'Extensions';
$_['text_edit']          = 'Edit Zaakpay';
$_['text_success']       = 'Success: Zaakpay account details have been modified!';
$_['text_zaakpay']      = '<a href="https://pay.mobikwik.com/" target="_blank"><img src="view/image/payment/zaakpaylogo.png" alt="Zaakpay" title="Zaakpay" style="border: 1px solid #EEEEEE;" /></a>';

$_['entry_merchantIdentifier']       = 'Merchant Identifier:';
$_['entry_secretKey']   = 'Secret Key:';
$_['entry_order_status'] = 'Order Status:';
$_['entry_status']       = 'Status';
$_['entry_sort_order']   = 'Sort Order';
$_['entry_live']   = 'Live Mode';

$_['help_credentials']        = 'The Api Key Id and Key Secret you will recieve from the Get Merchant Identifier section of Zaakpay Dashboard. Use test Key for testing purposes.';
$_['help_order_status']  = 'The status of the order to be marked on completion of payment.';

$_['error_permission']   = 'Warning: You do not have permission to modify  Zaakpay payment';
$_['error_merchantIdentifier']       = 'Merchant Identifier Required!';
$_['error_secretKey']   = 'Secret Key Required!';

$_['help_live']   = 'Production Mode';
$_['help_zaakpay_key']   = 'Enter Zaakpay Secret Key';
$_['help_zaakpay_merchantIdentifier']   = 'Enter Zaakpay Merchant Identifier';
$_['help_zaakpay_mode_status']   = 'Zaakpay Status for Users';


?>
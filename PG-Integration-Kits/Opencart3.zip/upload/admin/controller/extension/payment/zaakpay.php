<?php

class ControllerExtensionPaymentZaakpay extends Controller {

    private $error = array();

    public function index() {
        $this->language->load('extension/payment/zaakpay');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            
            $this->model_setting_setting->editSetting('payment_zaakpay', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
        }
     
        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_all_zones'] = $this->language->get('text_all_zones');
        $data['text_yes'] = $this->language->get('text_yes');
        $data['text_no'] = $this->language->get('text_no');


        $data['entry_merchantIdentifier'] = $this->language->get('entry_merchantIdentifier');
        $data['entry_secretKey'] = $this->language->get('entry_secretKey');


        $data['entry_order_status'] = $this->language->get('entry_order_status');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_sort_order'] = $this->language->get('entry_sort_order');

        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');

        $data['help_credentials'] = $this->language->get('help_credentials');
        $data['help_order_status'] = $this->language->get('help_order_status');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->request->post['payment_zaakpay_live'])) {
            $data['payment_zaakpay_live'] = $this->request->post['payment_zaakpay_live'];
        } else {
            $data['payment_zaakpay_live'] = $this->config->get('payment_zaakpay_live');
        }
        
        if (isset($this->error['zaakpay_merchantIdentifier'])) {
            $data['error_merchantIdentifier'] = $this->error['zaakpay_merchantIdentifier'];
        } else {
            $data['error_merchantIdentifier'] = '';
        }

        if (isset($this->error['zaakpay_secretKey'])) {
            $data['error_secretKey'] = $this->error['zaakpay_secretKey'];
        } else {
            $data['error_secretKey'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true),
            'separator' => false
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/payment/zaakpay', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['action'] = $this->url->link('extension/payment/zaakpay', 'user_token=' . $this->session->data['user_token'], true);

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);
        
        if (isset($this->request->post['payment_zaakpay_merchantIdentifier'])) {
            $data['payment_zaakpay_merchantIdentifier'] = $this->request->post['payment_zaakpay_merchantIdentifier'];
        } else {
            $data['payment_zaakpay_merchantIdentifier'] = $this->config->get('payment_zaakpay_merchantIdentifier');
        }

        if (isset($this->request->post['payment_zaakpay_secretKey'])) {
            $data['payment_zaakpay_secretKey'] = $this->request->post['payment_zaakpay_secretKey'];
        } else {
            $data['payment_zaakpay_secretKey'] = $this->config->get('payment_zaakpay_secretKey');
        }

        if (isset($this->request->post['payment_zaakpay_order_status_id'])) {
            $data['payment_zaakpay_order_status_id'] = $this->request->post['payment_zaakpay_order_status_id'];
        } else {
            $data['payment_zaakpay_order_status_id'] = $this->config->get('payment_zaakpay_order_status_id');
        }

        $this->load->model('localisation/order_status');

        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();


        if (isset($this->request->post['payment_zaakpay_status'])) {
            $data['payment_zaakpay_status'] = $this->request->post['payment_zaakpay_status'];
        } else {
            $data['payment_zaakpay_status'] = $this->config->get('payment_zaakpay_status');
        }


        if (isset($this->request->post['payment_zaakpay_sort_order'])) {
            $data['payment_zaakpay_sort_order'] = $this->request->post['payment_zaakpay_sort_order'];
        } else {
            $data['payment_zaakpay_sort_order'] = $this->config->get('payment_zaakpay_sort_order');
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/payment/zaakpay', $data));
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/payment/zaakpay')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->request->post['payment_zaakpay_merchantIdentifier']) {
            $this->error['payment_zaakpay_merchantIdentifier'] = $this->language->get('error_merchantIdentifier');
        }

        if (!$this->request->post['payment_zaakpay_secretKey']) {
            $this->error['payment_zaakpay_secretKey'] = $this->language->get('error_secretKey');
        }

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

}

?>
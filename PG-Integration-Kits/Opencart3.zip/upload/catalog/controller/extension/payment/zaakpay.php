<?php

class ControllerExtensionPaymentZaakpay extends Controller {

    public function index() {
        $data['button_confirm'] = $this->language->get('button_confirm');
        $this->language->load('extension/payment/zaakpay');
        $this->load->model('checkout/order');

        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        if($this->config->get('payment_zaakpay_live')){
            $data['action'] = 'https://api.zaakpay.com/api/paymentTransact/V8';
        } else {
            $data['action'] = 'https://zaakstaging.zaakpay.com/api/paymentTransact/V8';
        }

    $data['merchantIdentifier'] = $this->config->get('payment_zaakpay_merchantIdentifier');
    $data['secret_key'] = $this->config->get('payment_zaakpay_secretKey');
    $data['orderId']=  $this->session->data['order_id']; 
    $data['buyerEmail']     = $order_info['email'];
    $data['currency']   = "INR";
    $data['amount'] = (float) $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false) * 100;
    $data['buyerFirstName']     = $order_info['payment_firstname'];
    $data['buyerLastName']     = $order_info['payment_lastname'];
    $data['buyerCity']      = $order_info['payment_city'];
    $data['buyerPhoneNumber']   = $order_info['telephone'];
    $data['txnType']    = "1";
    $data['zpPayOption']    = "1";
    $data['mode']    = "0";
    $data['returnUrl'] = $this->url->link('extension/payment/zaakpay/callback');
    $data['productDescription'] =   $this->session->data['payment_method']['title'];
    $data['purpose']    = "1";
    $merchantIdentifier = $this->config->get('payment_zaakpay_merchantIdentifier');
    $secret_key = $this->config->get('payment_zaakpay_secretKey');
    $orderId = $data['orderId'];
    $buyerEmail = $order_info['email'];
    $currency="INR";
    $amount=    (int) $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false) * 100;
    $buyerFirstName = $order_info['payment_firstname'];
    $buyerLastName = $order_info['payment_lastname'];
    $buyerCity = $order_info['payment_city'];
    $buyerPhoneNumber = $order_info['telephone'];
    $txnType="1";
    $zpPayOption="1";
    $productDescription=$this->session->data['payment_method']['title'];
    $purpose="1";
    $returnUrl = $this->url->link('extension/payment/zaakpay/callback');
    $mode="0";
    $post_variables = Array("amount" => $amount,"buyerCity" => $buyerCity,"buyerEmail" =>$buyerEmail,"buyerFirstName" => $buyerFirstName,"buyerLastName" => $buyerLastName,"buyerPhoneNumber" => $buyerPhoneNumber,"currency" => $currency,"merchantIdentifier" => $merchantIdentifier,"mode" => $mode,"orderId" => $orderId,"productDescription" => $productDescription,"purpose" => $purpose,"returnUrl" => $returnUrl,"txnType" => $txnType,"zpPayOption" => $zpPayOption);

    $all = '';
    foreach($post_variables as $name => $value) {
        if($name !='button_confirm') 
            {
                if($name !='button_back') 
                {
                    if($name != 'action') 
                    {
                        if($name != 'secret_key') 
                        { 
                            if($name != 'checksum') 
                            {
                                if($value!=''){
                                    $all.=$name;
                                    $all.="=";      
                                    $all .= $value;
                                    $all .= "&";
                                }
                            }
                       }
                    }
                }
            }
        }

    foreach($data as $name => $value) {
        if($name !='button_confirm') 
            { if($name !='button_back') 
                { if($name != 'action') 
                    { if($name != 'secret_key') 
                        { if($name != 'checksum') {
                          $data[$name]= $value;
                        }
                    }
                }
            }
        }
    }

    if($this->config->get('Zaakpay_log') == "on")
        {           
            error_log("AllParams : ".$all);
            error_log("Secret Key : ".$secret_key);
        }
        
        $checksum = ControllerExtensionPaymentZaakpay::calculateChecksum($secret_key, $all);
        $data['checksum'] = $checksum;
        $this->id = 'payment';
    return $this->load->view('extension/payment/zaakpay', $data);
    }

    function calculateChecksum($secret_key, $all) {
            $hash = hash_hmac('sha256', $all , $secret_key);
            // echo "SecretKey IN Calculate Checksum: ";
            // echo $secret_key;
            $checksum = $hash;
            return $checksum;
        }


    function verifyChecksum($checksum, $all, $secret_key) {
            $cal_checksum = ControllerExtensionPaymentZaakpay::calculateChecksum($secret_key, $all);
            $bool = 0;
            

            if($checksum == $cal_checksum)  {
                $bool = 1;
            }

            return $bool;
        }



    public function callback() {
        if (isset($this->request->post['orderId'])) {
            $order_id = $this->request->post['orderId'];
        } else {
            $order_id = 0;
        }
        $this->load->model('checkout/order');
         
        if (isset($this->request->request['pgTransId']) and isset($this->request->request['orderId'])) {

            $pgTransId = $this->request->request['pgTransId'];
            $orderId = $this->request->request['orderId'];
            $order_info = $this->model_checkout_order->getOrder($orderId);
            $merchantIdentifier = $this->config->get('payment_zaakpay_merchantIdentifier');
            $secret_key = $this->config->get('payment_zaakpay_secretKey');

            $amount             =   $this->request->post['amount'];
            $bank             =   $this->request->post['bank'];
            $bankid             =   $this->request->post['bankid'];
            $cardId             =   $this->request->post['cardId'];
            $cardScheme             =   $this->request->post['cardScheme'];
            $cardToken             =   $this->request->post['cardToken'];
            $cardhashid             =   $this->request->post['cardhashid'];
            $doRedirect             =   $this->request->post['doRedirect'];
            $paymentMode             =   $this->request->post['paymentMode'];
            $paymentMethod             =   $this->request->post['paymentMethod'];
            $responseCode             =   $this->request->post['responseCode'];
            $responseDescription             =   $this->request->post['responseDescription'];
            $productDescription             =   $this->request->post['productDescription'];
            $product1Description             =   $this->request->post['product1Description'];
            $product2Description             =   $this->request->post['product2Description'];
            $product3Description             =   $this->request->post['product3Description'];
            $product4Description             =   $this->request->post['product4Description'];
            $pgTransId             =   $this->request->post['pgTransId'];
            $pgTransTime             =   $this->request->post['pgTransTime'];
            $checksum             =   $this->request->post['checksum'];


        $post_checksum_variables = Array(
        "amount" => $amount, //Amount should be in paisa
        "bank" => $bank,
        "bankid" => $bankid,
        "cardId" => $cardId,
        "cardScheme" => $cardScheme,
        "cardToken" => $cardToken,
        "cardhashid" => $cardhashid,
        "doRedirect" => $doRedirect,
        "orderId" => $orderId,
        "paymentMethod" => $paymentMethod,
        "paymentMode" => $paymentMode,
        "responseCode" => $responseCode,
        "responseDescription" => $responseDescription,
        "productDescription" => $productDescription,
        "product1Description" => $product1Description,
        "product2Description" => $product2Description,
        "product3Description" => $product3Description,
        "product4Description" => $product4Description,
        "pgTransId" => $pgTransId,
        "pgTransTime" => $pgTransTime);

        $all1 = '';
        foreach($post_checksum_variables as $name => $value) {
        if($name !='button_confirm') 
            {
                if($name !='button_back') 
                {
                     if($name != 'action') 
                    {
                         if($name != 'secret_key') 
                          { 
                            if($name != 'checksum') 
                            {
                                if($value!=''){
                                $all1.=$name;
                                $all1.="=";      
                                $all1 .= $value;
                                $all1 .= "&";
                                }
                            }
                          }
                    }
                }
            }
        }


        if($this->config->get('Zaakpay_log') == "on")
            {           
                error_log("AllParams : ".$all1);
                error_log("Secret Key : ".$secret_key);
            }
         

    
    $ischecksumEqual = ControllerExtensionPaymentZaakpay::verifyChecksum($checksum, $all1,$secret_key);

            $data['charset'] = $this->language->get('charset');
            $data['language'] = $this->language->get('code');
            $data['direction'] = $this->language->get('direction');
            $data['heading_title'] = sprintf($this->language->get('heading_title'), $order_info['payment_method']);
            $data['responseDescription']= $responseDescription ;  
 
            $res =  $this->request->post['responseCode'];
            
            if ($ischecksumEqual == 1 &&  $this->request->post['responseCode'] == 100 ) {


                if (!$order_info['order_status_id']) {
                    $this->model_checkout_order->addOrderHistory($orderId, $this->config->get('payment_zaakpay_order_status_id'), 'Payment Successful. Zaakpay Transaction Id:' . $pgTransId, true);
                     
                } else {
                    $this->model_checkout_order->addOrderHistory($orderId, $this->config->get('payment_zaakpay_order_status_id'), 'Payment Successful. Zaakpay Transaction Id:' . $pgTransId, true);
                }  

                echo '<html>' . "\n";
                echo '<head>' . "\n";
                echo '  <meta http-equiv="Refresh" content="0; url=' . $this->url->link('checkout/success') . '">' . "\n";
                echo '</head>' . "\n";
                echo '</html>' . "\n";
                exit();               

            }else {
                 if($this->request->post['responseCode'] == 102){
                $this->model_checkout_order->addOrderHistory($this->request->request['orderId'], 10,  'Payment Failed! '.$responseDescription .'  Zaakpay Transaction Id:' . $pgTransId);
                
                 }else{                 
                
                $this->model_checkout_order->addOrderHistory($this->request->request['orderId'], 10, 'Payment Failed!'.$responseDescription .' Check Zaakpay dashboard for details. Zaakpay Transaction Id:' . $pgTransId);
                
 
                }
                echo '<html>' . "\n";
                echo '<head>' . "\n";
                echo '  <meta http-equiv="Refresh" content="0; url=' . $this->url->link('checkout/failure') . '">' . "\n";
                echo '</head>' . "\n";
                echo '<body>' . "\n";
                echo ' <div style="text-align: center;"><p><b>'."Do not press Back Button. Your transcation might fail. We are redirecting you to Merchant Site"."\n";
                echo '</b></p></div>'."\n";
                echo '</body>' . "\n";

                echo '</html>' . "\n";
                exit();

            }
                             
          }
    }  
 }
?>

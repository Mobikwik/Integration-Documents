<?php 
class ModelExtensionPaymentZaakpay extends Model {
    public function getMethod($address, $total) {
        $this->language->load('extension/payment/zaakpay');
        
        $method_data = array( 
            'code'       => 'zaakpay',
            'title'      => $this->language->get('text_title'),
            'terms'      => '',
            'sort_order' => $this->config->get('payment_zaakpay_sort_order')
        );
   
        return $method_data;
    }
}
?>
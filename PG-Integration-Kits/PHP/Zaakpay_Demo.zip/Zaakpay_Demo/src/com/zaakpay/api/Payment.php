<!-- Below code is used to show the checksum calculating parameters and checksum string -->
<!-- =========================================================================================================================== -->

<?php

	if(array_key_exists('orderId', $_POST) and !(array_key_exists('checksum', $_POST))) { 
    	require_once('./../lib/Checksum.php');
	   	require_once('./../../../resources/Config.php');

        $keys = array_keys($_POST);
        $size = count($keys);
        for($i=0; $i<$size; $i++)
            $_POST[$keys[$i]] = urlencode($_POST[$keys[$i]]);

        $_POST["returnUrl"] = $returnUrl;


        $checksumFlag = $environment != "https://api.zaakpay.com" ; //This should not be changed
	   	
		$all = Checksum::getAllParams();
		$checksum = Checksum::calculateChecksum($secretKey, $all); 	 //This is used to generate checksum
 ?>

<?php if ($checksumFlag) { ?>

<html>
<head>
	<link rel="stylesheet" href="./../css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Request Parameters</title>
</head>
<body>
<br><br>
	<div align="center">
        <div class="paymentCheckParameter card-info p-3">
            <div class="pt-2">
                <h4>REQUEST PARAMETERS</h4>
            </div>
            <form action="<?php echo $environment.$transactApi ; ?>" method="post">
			<table class="table table-bordered" >
                <thead class="table-dark">
                    <tr>
                        <td align="center" valign="middle">Parameter</td>
                        <td align="center" valign="middle">Value</td>
                    </tr>
                </thead>
                <tbody>
				<tr>
					<td width="50%" align="center" valign="middle">Order Id</td>
					<td width="50%" align="center" valign="middle"><?php echo $_POST['orderId'] ?></td>
				</tr>
				<tr>
					<td align="center" valign="middle">Checksum String</td>
					<td align="center" valign="middle"><?php echo htmlentities($all) ?></td>
				</tr>
				<tr>
					<td align="center" valign="middle">Calculated Checksum</td>
					<td align="center" valign="middle"><?php echo $checksum ?></td>
				</tr>
				</tbody>
			</table>
			<?php Checksum::outputForm($checksum); ?>
            <div class="col-12 mt-4">
                <button class="btn btn-primary">Process Payment</button>
            </div>
		</form>
        </div>
	</div>

</body>
</html>
<?php } ?>

<?php if (!$checksumFlag) { ?>
<center>
<table width="500px;">
	<tr>
		<td align="center" valign="middle">Do Not Refresh or Press Back <br/> Redirecting to Zaakpay</td>
	</tr>
	<tr>
		<td align="center" valign="middle">
			<form action="<?php echo $environment.$transactApi ; ?>" method="post">
				<?php
				Checksum::outputForm($checksum);
				?>
			</form>
		</td>
	</tr>
</table>
</center>
<script type="text/javascript">
var form = document.forms[0];
form.submit();
</script>
<?php } ?>

<?php } ?>


<!-- Below code is used to enter the sample Input -->
<!-- =========================================================================================================================== -->

<?php if(!array_key_exists('orderId', $_POST)) {
   	require_once('./../../../resources/Config.php');  
 ?>
<html>
<head>
	<link rel="stylesheet" href="./../css/style.css">
   	<title>Sample Input</title>
   	<script type="text/javascript">


	function autoPop(){
		document.getElementById("orderId").value= "ZPLive" + String(new Date().getTime());	//	Autopopulating orderId
		var today = new Date();
		var dateString = String(today.getFullYear()).concat("-").concat(String(today.getMonth()+1)).concat("-").concat(String(today.getDate()));
		document.getElementById("txnDate").value= dateString;
	};
   	</script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</head>

<body onload="autoPop()">

<div align="center">
    <div>
        <h2>Pay Now to see how Zaakpay will work on your website.</h2>
        <p>Note: This page behaves like a shopping cart or checkout page on a website.</p>
    </div>
    <form class="column g-3 needs-validation pt-2" novalidate action="Payment.php" method="post">
        <div class="mandatoryParameters card-info p-3">
        <h4>MANDATORY PARAMETERS</h4>
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <td align="center" valign="middle">Parameter</td>
                    <td align="center" valign="middle">Value</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td width="50%" align="right" valign="middle">Merchant Identifier</td>
                    <td width="50%" align="center" valign="middle">
                        <input type="text" class="form-control" name="merchantIdentifier" value="<?php echo $merchantIdentifier ; ?>" pattern="^[a-zA-Z0-9]+$" required/>
                        <div class="invalid-feedback"> AlphaNumeric Characters Only! </div>
                    </td>
                </tr>
                <tr>
                    <td width="50%" align="right" valign="middle">Order Id</td>
                    <td width="50%" align="center" valign="middle">
                        <input type="text" class="form-control" id="orderId" name="orderId" pattern="^[a-zA-Z0-9]+$" required/>
                        <div class="invalid-feedback"> AlphaNumeric Characters Only! </div>
                    </td>
                </tr>
                <tr>
                      <input type="hidden" name="returnUrl" value="<?php echo $returnUrl; ?>"/>
                      <input type="hidden" name="currency" value="INR" />
                </tr>
                <tr>
                    <td width="50%" align="right" valign="middle">Amount In Paisa</td>
                    <td width="50%" align="center" valign="middle">
                        <input type="number" step=".01" class="form-control" name="amount" value="100" placeholder="In Paisa"  required />
                        <div class="invalid-feedback"> Numeric Characters Only! </div>
                    </td>
                </tr>
                <tr>
                    <td width="50%" align="right" valign="middle">Buyer Email</td>
                    <td width="50%" align="center" valign="middle">
                        <input type="email" class="form-control" name="buyerEmail" value="" required />
                        <div class="invalid-feedback"> Enter Valid Email! </div>
                    </td>
                </tr>
            </tbody>
        </table>
            <div class="col-12 mt-4">
                <button class="btn btn-primary" type="submit">Pay Now</button>
            </div>
        </div>
        <br><br>

<!-- ========================== OPTIONAL PARAMETERS ================================ --->
        <div class="mandatoryParameters card-info p-3">
        <h4>OPTIONAL PARAMETERS</h4>
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <td align="center" valign="middle">Parameter</td>
                    <td align="center" valign="middle">Value</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td width="50%" align="right" valign="middle">Buyer First Name</td>
	                <td width="50%" align="center" valign="middle">
                        <input type="text" class="form-control" name="buyerFirstName" value="" pattern="^[a-zA-Z0-9]+$"/>
                    </td>
                </tr>
                <tr>
	                <td width="50%" align="right" valign="middle">Buyer Last Name</td>
	                <td width="50%" align="center" valign="middle">
                        <input type="text" class="form-control" name="buyerLastName" value="" pattern="^[a-zA-Z0-9]+$"/>
                    </td>
                </tr>
                <tr>
                    <td width="50%" align="right" valign="middle">Buyer Address</td>
                    <td width="50%" align="center" valign="middle">
                        <input type="text" class="form-control" name="buyerAddress" value="" pattern="^[a-zA-Z0-9]+$"/>
                    </td>
                </tr>
                <tr>
                    <td width="50%" align="right" valign="middle">Buyer City</td>
                    <td width="50%" align="center" valign="middle">
                        <input type="text" class="form-control" name="buyerCity" value="" pattern="^[a-zA-Z]+$"/>
                    </td>
                </tr>
                <tr>
                    <td width="50%" align="right" valign="middle">Buyer State</td>
                    <td width="50%" align="center" valign="middle">
                        <input type="text" class="form-control" name="buyerState" value="" pattern="^[a-zA-Z]+$"/>
                    </td>
                </tr>
                <tr>
                    <td width="50%" align="right" valign="middle">Buyer Country</td>
                    <td width="50%" align="center" valign="middle">
                        <input type="text" class="form-control" name="buyerCountry" value="" pattern="^[a-zA-Z]+$"/>
                    </td>
                </tr>
                <tr>
                    <td width="50%" align="right" valign="middle">Buyer Pincode</td>
                    <td width="50%" align="center" valign="middle">
                        <input type="number" class="form-control" name="buyerPincode" value=""/>
                    </td>
                </tr>
                <tr>
                    <td width="50%" align="right" valign="middle">Buyer Phone No</td>
                    <td width="50%" align="center" valign="middle">
                        <input type="number" class="form-control" name="buyerPhoneNumber" value="" />
                    </td>
                </tr>
                <tr>
                    <td width="50%" align="right" valign="middle">Product Description</td>
                    <td width="50%" align="center" valign="middle">
                        <input type="text" class="form-control" name="productDescription" pattern="^[a-zA-Z0-9]+$"/>
                    </td>
                </tr>
            </tbody>
        </table>
        </div>

<!-- Not mandatory  -->
<!-- <tr>	
	<td width="50%" align="right" valign="middle">Product1 Description</td>
	<td width="50%" align="center" valign="middle"><input type="hidden" name="product1Description" /></td>
</tr> -->
<!-- <tr>
	<td width="50%" align="right" valign="middle">IPaddress</td>
	<td width="50%" align="center" valign="middle"><input type="text" name="merchantIpAddress" /> </td>
</tr> -->
<!-- <tr>
	<td width="50%" align="right" valign="middle">Purpose</td>
	<td width="50%" align="center" valign="middle"><input type="text" name="purpose" /></td>
</tr> -->
<!-- <tr>	
	<td width="50%" align="right" valign="middle">Txntype</td>
	<td width="50%" align="center" valign="middle"><input type="text" name="txnType" value="1" /></td>
</tr>
<tr>
	<td width="50%" align="right" valign="middle">Zppayoption</td>
	<td width="50%" align="center" valign="middle"><input type="text" name="zpPayOption" value="1" /></td>
</tr>
<tr>
	<td width="50%" align="right" valign="middle">Mode</td>
	<td width="50%" align="center" valign="middle"><input type="text" name="mode" value="1" /> </td>
</tr>
<tr>
	<td width="50%" align="right" valign="middle">Currency</td>
	<td width="50%" align="center" valign="middle"><input type="text" name="currency" value="INR" /></td>
</tr>
 -->
<!--<tr>	
	<td width="50%" align="right" valign="middle">Product2 Description</td>
	<td width="50%" align="center" valign="middle"> </td>
</tr>-->
<!-- Not mandatory <input type="hidden" name="product2Description" /> -->

<!--<tr>	
	<td width="50%" align="right" valign="middle">Product3 Description</td>
	<td width="50%" align="center" valign="middle"> </td>
</tr>-->
<!-- Not mandatory <input type="hidden" name="product3Description" /> -->

<!--<tr>	
	<td width="50%" align="right" valign="middle">Product4 Description</td>
	<td width="50%" align="center" valign="middle"> </td>
</tr>-->
<!-- Not mandatory <input type="hidden" name="product4Description" /> -->

<!--<tr>
	<td width="50%" align="right" valign="middle">Ship To Address</td>
	<td width="50%" align="center" valign="middle"> </td>
</tr>-->
<!-- Not mandatory <input type="hidden" name="shipToAddress" /> -->

<!--<tr>
	<td width="50%" align="right" valign="middle">Ship To City</td>
	<td width="50%" align="center" valign="middle"> </td>
</tr>-->
<!-- Not mandatory <input type="hidden" name="shipToCity" /> -->

<!--<tr>
	<td width="50%" align="right" valign="middle">Ship To State</td>
	<td width="50%" align="center" valign="middle"></td>
</tr>-->
<!-- Not mandatory <input type="hidden" name="shipToState" /> -->

<!--<tr>	
	<td width="50%" align="right" valign="middle">Ship To Country</td>
	<td width="50%" align="center" valign="middle"> </td>
</tr>-->
<!-- Not mandatory <input type="hidden" name="shipToCountry" /> -->

<!--<tr>
	<td width="50%" align="right" valign="midb6415a6443604ec59644a70c8b25a0f6dle">Ship To Pincode</td>
	<td width="50%" align="center" valign="middle"> </td>
</tr>-->
<!-- Not mandatory <input type="hidden" name="shipToPincode" /> -->

<!--<tr>
	<td width="50%" align="right" valign="middle">Ship To Phone Number</td>
	<td width="50%" align="center" valign="middle"> </td>
</tr>-->
<!-- Not mandatory <input type="hidden" name="shipToPhoneNumber" /> -->

<!--<tr>
	<td width="50%" align="right" valign="middle">Ship To Firstname</td>
	<td width="50%" align="center" valign="middle"></td>
</tr>-->
<!-- Not mandatory <input type="hidden" name="shipToFirstname" /> -->

<!--<tr>
	<td width="50%" align="right" valign="middle">Ship To Lastname</td>
	<td width="50%" align="center" valign="middle"></td>
</tr>-->
<!-- Not mandatory <input type="hidden" name="shipToLastname" /> -->
<!-- 
<tr>
	<td width="50%" align="right" valign="middle">Transaction Date "YYYY-MM-DD"</td>
	<td width="50%" align="center" valign="middle"><input type="text" name="txnDate" id="txnDate" /></td>
</tr> -->
</form>
</div>
<br><br><br><br><br>
</body>
<script>
    (function () {
        'use strict';

        var forms = document.querySelectorAll('.needs-validation');

        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }

                    form.classList.add('was-validated');
                }, false)
            })
    })();
</script>
</html>
<?php } ?>

<!-- =========================================================================================================================== -->
<!-- Below code is used to show the checksum calculating parameters and checksum string -->
<!-- =========================================================================================================================== -->
<?php
   if(array_key_exists('orderId', $_POST) and !(array_key_exists('checksum', $_POST))) {
      require_once('./../lib/Checksum.php');
         require_once('./../../../resources/Config.php');

         $keys = array_keys($_POST);
         $size = count($keys);
         for($i=0; $i<$size; $i++)
             $_POST[$keys[$i]] = urlencode($_POST[$keys[$i]]);


      $checksumFlag = $environment != "https://api.zaakpay.com" ; //This should not be changed

      $all = Checksum::getAllParamsCheckandUpdate();
      $checksum = Checksum::calculateChecksum($secretKey, $all);
?>

<?php if ($checksumFlag) { ?>


<html>
<head>
   <link rel="stylesheet" href="./../css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <title>Request Parameters</title>

</head>
<body>
<br><br>
   <div align="center">
       <div class="refundCheckParameter card-info p-3">
       <div class="pt-2">
           <h4>REQUEST PARAMETERS</h4>
       </div>
       <form action="<?php echo $environment.$updateApi ; ?>" method="post">
         <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <td align="center" valign="middle">Parameter</td>
                    <td align="center" valign="middle">Value</td>
                </tr>
            </thead>
             <tbody>
             <tr>
               <td width="50%" align="center" valign="middle">Order Id</td>
               <td width="50%" align="center" valign="middle"><?php echo $_POST['orderId'] ?></td> 
            </tr>
            <tr>
               <td align="center" valign="middle">Checksum String <br> ( Raw Request )</td>
               <td><?php echo $all ?></td>
            </tr>
            <tr>
               <td align="center" valign="middle">Calculated Checksum</td>
               <td><?php echo $checksum ?></td>
            </tr>
             </tbody>
         </table>
           <div class="col-12 mt-4">
               <button class="btn btn-primary">Refund</button>
           </div>
         <?php Checksum::outputForm($checksum); ?>
      </form>
       </div>
   </div>
</body>
</html>
<?php } ?>

<?php if (!$checksumFlag) { ?>

<center>
<table width="500px;">
  <tr>
    <td align="center" valign="middle">Do Not Refresh or Press Back <br/> Redirecting to Zaakpay</td>
  </tr>
  <tr>
    <td align="center" valign="middle">
      <form action="<?php echo $environment.$updateApi ; ?>" method="post">
        <?php
        Checksum::outputForm($checksum);
        ?>
      </form>
    </td>
  </tr>
</table>
</center>
<script type="text/javascript">
var form = document.forms[0];
form.submit();
</script>

<?php } ?>


<?php } ?>


<!-- Below code is used to enter the sample Input -->
<!-- =========================================================================================================================== -->
<?php require_once('./../../../resources/Config.php'); ?>  
<?php if(!array_key_exists('orderId', $_POST)) { ?>
<html>
<head>
	<link rel="stylesheet" href="./../css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Refund Transaction</title>
</head>
<body>
<br><br>
<div align="center">
    <div class="fullRefund card-info pt-3">
        <div class="pt-2">
            <h2>Full Refund.</h2>
            <p>This will initiate full refund for the transaction .</p>
        </div>
	    <form class="column g-3 needs-validation pt-2" novalidate action="Refund.php" method="post">
            <div class="col-md-6 form-floating mb-3">
                <input type="text" class="form-control" id="fullRefundMerchantIdentifier" name="merchantIdentifier" placeholder="Merchant Idenitfier" value="<?php echo $merchantIdentifier ?>" pattern="^[a-zA-Z0-9]+$" required>
                <label for="fullRefundMerchantIdentifier" class="form-label">Merchant Identifier : </label>
                <div class="invalid-feedback"> AlphaNumeric Characters Only! </div>
            </div>
            <div class="col-md-6 form-floating mb-3">
                <input type="text" class="form-control" id="fullRefundOrderId" name="orderId" placeholder="Enter orderId" pattern="^[a-zA-Z0-9]+$">
                <label for="fullRefundOrderId" class="form-label">Order Id : </label>
                <div class="invalid-feedback"> AlphaNumeric Characters Only! </div>
            </div>
                <input type="hidden" name="mode" value="0" >
                <input type="hidden" name="updateDesired" value="14" >
                <input type="hidden" name="updateReason" value="Testing">
            <div class="col-12 mt-4">
                <button class="btn btn-primary" type="submit">Initiate Full Refund</button>
            </div>
        </form>
    </div>

    <br><br>

    <div class="partialRefund card-info pt-3">
        <div class="pt-2">
            <h2>Partial Refund</h2>
            <p>This will initiate partial refund for the transaction .</p>
        </div>
        <form class="column g-3 needs-validation pt-2" novalidate action="Refund.php" method="post">

            <div class="col-md-6 form-floating mb-3">
                <input type="text" class="form-control" id="partialRefundMerchantIdentifier" name="merchantIdentifier" placeholder="Merchant Identifier" value="<?php echo $merchantIdentifier ?>" pattern="^[a-zA-Z0-9]+$" required>
                <label for="partialRefundMerchantIdentifier" class="form-label">Merchant Identifier : </label>
                <div class="invalid-feedback"> AlphaNumeric Characters Only! </div>
            </div>
            <div class="col-md-6 form-floating mb-3">
                <input type="text" class="form-control" id="partialRefundOrderId" name="orderId" placeholder="Enter orderId" pattern="^[a-zA-Z0-9]+$">
                <label for="partialRefundOrderId" class="form-label">Order Id : </label>
                <div class="invalid-feedback"> AlphaNumeric Characters Only! </div>
            </div>
            <input type="hidden" name="mode" value="0" >
            <input type="hidden" name="updateDesired" value="22" >
            <input type="hidden" name="updateReason" value="Test reason">
            <div class="col-md-6 form-floating mb-3">
                <input type="number" step=".01" class="form-control" id="amountField" name="amount" placeholder="Enter Amount ( Paisa )" >
                <label for="amountField" class="form-label">Amount : </label>
                <div class="invalid-feedback"> Numeric Characters Only! </div>
            </div>
            <div class="col-12 mt-4">
                <button class="btn btn-primary" type="submit">Initiate Partial Refund</button>
            </div>
        </form>
    </div>
</div>
<br><br><br><br><br>
</body>
<script>
    (function () {
        'use strict';

        var forms = document.querySelectorAll('.needs-validation');

        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }

                    form.classList.add('was-validated');
                }, false)
            })
    })();
</script>
</html>
<?php } ?>`
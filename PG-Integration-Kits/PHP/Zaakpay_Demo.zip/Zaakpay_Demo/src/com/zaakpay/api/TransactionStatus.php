<!-- Below code is used to show the checksum calculating parameters and checksum string -->
<!-- =========================================================================================================================== -->
<?php
	if(array_key_exists('orderId', $_POST) and !(array_key_exists('checksum', $_POST))) {
		require_once('./../lib/Checksum.php');   
	   	require_once('./../../../resources/Config.php');

        $keys = array_keys($_POST);
        $size = count($keys);
        for($i=0; $i<$size; $i++)
            $_POST[$keys[$i]] = urlencode($_POST[$keys[$i]]);


        $checksumFlag = $environment != "https://api.zaakpay.com" ; //This should not be changed

		$data = "{merchantIdentifier:".$_POST['merchantIdentifier'].",mode:0,orderDetail:{orderId:".$_POST['orderId']."}}" ;
		$checksum = Checksum::calculateChecksum($secretKey, $data);
?>

<?php if ($checksumFlag) { ?>

<html>
<head>
	<link rel="stylesheet" href="./../css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Request Parameters</title>
</head>
<body>
<br><br>
	<div align="center">
        <div class="transactionCheckParameter card-info p-3">
            <div class="pt-2">
                <h4>REQUEST PARAMETERS</h4>
            </div>
            <form action="<?php echo $environment.$checkStatusApi ; ?>" method="post">
			<table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <td align="center" valign="middle">Parameter</td>
                        <td align="center" valign="middle">Value</td>
                    </tr>
                </thead>
                <tbody>
                <tr>
					<td width="50%" align="center" valign="middle">Order Id</td>
					<td width="50%" align="center" valign="middle"><?php echo $_POST['orderId'] ?></td> 
				</tr>
				<tr>
					<td align="center" valign="middle">Checksum String</td>
					<td><?php echo $data ?></td>
				</tr>
				<tr>
					<td align="center" valign="middle">Calculated Checksum</td>
					<td><?php echo $checksum ?></td>
				</tr>
				</tbody>
			</table>
			<input type="hidden" name="data" value="<?php echo $data ; ?>" />
    		<input type="hidden" name="checksum" value="<?php echo $checksum ; ?>"/>
            <div class="col-12 mt-4">
                <button class="btn btn-primary">Check Status</button>
            </div>
		</form>
        </div>
	</div>
</body>
</html>
<?php } ?>

<?php if (!$checksumFlag) { ?>
<center>
<table width="500px;">
	<tr>
		<td align="center" valign="middle">Do Not Refresh or Press Back <br/> Redirecting to Zaakpay</td>
	</tr>
	<tr>
		<td align="center" valign="middle">
			<form action="<?php echo $environment.$checkStatusApi ; ?>" method="post">
				<input type="hidden" name="data" value="<?php echo $data ; ?>" />
    			<input type="hidden" name="checksum" value="<?php echo $checksum ; ?>"/>
			</form>
		</td>
	</tr>
</table>
</center>
<script type="text/javascript">
var form = document.forms[0];
form.submit();
</script>
<?php } ?>

<?php } ?>



<!-- Below code is used to enter the sample Input -->
<!-- =========================================================================================================================== -->

<?php if(!array_key_exists('orderId', $_POST)) { 
   	require_once('./../../../resources/Config.php');  

	?>
<!DOCTYPE html>
<html>
<head>
	<title>Check Transaction Status</title>
	<link rel="stylesheet" href="./../css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</head>
<body>
<br><br>
	<div align="center">
        <div class="transactionStatus card-info p-3">
            <div class="pt-2">
                <h2>Transaction Status</h2>
                <p>This Page behaves like testing input for status check api </p>
            </div>
		    <form class="column g-3 needs-validation pt-2" novalidate action="TransactionStatus.php" method="post">
			<table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <td align="center" valign="middle">Parameter</td>
                        <td align="center" valign="middle">Value</td>
                    </tr>
                </thead>
				<tbody>
                    <tr>
					    <td width="50%" align="center" valign="middle">Merchant Identifier</td>
					    <td width="50%" align="center" valign="middle">
                            <input type="text" class="form-control" name="merchantIdentifier" value="<?php echo $merchantIdentifier ?>" pattern="^[a-zA-Z0-9]+$" required />
                            <div class="invalid-feedback"> AlphaNumeric Characters Only! </div>
                        </td>
                    </tr>
			    	<tr>
				    	<td width="50%" align="center" valign="middle">Order Id</td>
					    <td width="50%" align="center" valign="middle">
                            <input type="text" class="form-control" name="orderId" placeholder="Enter orderId" pattern="^[a-zA-Z0-9]+$" />
                            <div class="invalid-feedback"> AlphaNumeric Characters Only! </div>
                        </td>
				    </tr>
                </tbody>
			</table>
                <div class="col-12 mt-4">
                    <button class="btn btn-primary" type="submit">Check Status</button>
                </div>
		</form>
        </div>
	</div>
</body>
<script>
    (function () {
        'use strict';

        var forms = document.querySelectorAll('.needs-validation');

        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }

                    form.classList.add('was-validated');
                }, false)
            })
    })();
</script>
</html>
<?php } ?>


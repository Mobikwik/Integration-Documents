<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}

class mobikwikpg extends PaymentModule
{
    protected $_html = '';
    protected $_postErrors = array();


    function __construct() {
        $this->name = 'mobikwikpg';
        $this->tab = 'payments_gateways';
        $this->version = 1.0;
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->author = 'pay.mobikwik.com';

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('Mobikwik Payment Gateway', array(), 'Modules.Mobikwikpg.Admin');
        $this->description = $this->trans('Pay Using Mobikwik Payment Gateway', array(), 'Modules.Mobikwikpg.Admin');
        $this->confirmUninstall = $this->trans('Are you sure you want to delete these details?', array(), 'Modules.Mobikwikpg.Admin');
        

        $merchant_identifier= Configuration::get('MERCHANT_IDENTIFIER');
        $secret_key= Configuration::get('SECRET_KEY');
        $gateway_mode= Configuration::get('GATEWAY_MODE');

        $this->page = basename(__FILE__, '.php');

    }

    public function install() {

      Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state` ( `invoice`, `send_email`, `color`, `unremovable`, `logable`, `delivery`, `module_name`) VALUES  (0, 0, \'#33FF99\', 0, 1, 0, \'mobikwikpg\');');
      $id_order_state = (int) Db::getInstance()->Insert_ID();
      Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state_lang` (`id_order_state`, `id_lang`, `name`, `template`) VALUES ('.$id_order_state.', 1, \'Payment accepted\', \'payment\')');
      Configuration::updateValue('MOBIKWIKPG_ID_ORDER_SUCCESS', $id_order_state);     
      unset($id_order_state);
        
      Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state`( `invoice`, `send_email`, `color`, `unremovable`, `logable`, `delivery`, `module_name`) VALUES (0, 0, \'#33FF99\', 0, 1, 0, \'mobikwikpg\');');
      $id_order_state = (int) Db::getInstance()->Insert_ID();
      Db::getInstance()->Execute('INSERT INTO `' . _DB_PREFIX_ . 'order_state_lang` (`id_order_state`, `id_lang`, `name`, `template`) VALUES ('.$id_order_state.', 1, \'Payment Failed\', \'payment\')');
      Configuration::updateValue('MOBIKWIKPG_ID_ORDER_FAILED', $id_order_state);    
      unset($id_order_state);
      if (!parent::install() || !$this->registerHook('paymentOptions')) {
            return false;
        }
        return true;

    }

    public function uninstall() {
      Db::getInstance()->Execute('DELETE FROM `' . _DB_PREFIX_ . 'order_state_lang` WHERE id_order_state = '.Configuration::get('MOBIKWIKPG_ID_ORDER_SUCCESS').' and id_lang = 1' );
      Db::getInstance()->Execute('DELETE FROM `' . _DB_PREFIX_ . 'order_state_lang`  WHERE id_order_state = '.Configuration::get('MOBIKWIKPG_ID_ORDER_FAILED').' and id_lang = 1');
      return Configuration::deleteByName('MERCHANT_IDENTIFIER')
        && Configuration::deleteByName('SECRET_KEY')
        &&Configuration::get('GATEWAY_MODE')
        && parent::uninstall();
    }

    public function hookPaymentOptions($params) {
      if (!$this->active) {
        return;
      }
      $payment_option = new PaymentOption();
      $gateway_mode= Configuration::get('GATEWAY_MODE');

      if ($gateway_mode == 'sandbox') {
        $action = "https://zaakstaging.zaakpay.com/api/paymentTransact/V8";
      }
      else {
        $action = "https://api.zaakpay.com/api/paymentTransact/V8";
      }
      $inputs = $this->mbkpginputs();

      $payment_option->setCallToActionText($this->l('Pay by Mobikwik Payment Gateway'))->setAction($action)->setInputs($inputs)->setAdditionalInformation($this->context->smarty->fetch('module:mobikwikpg/mobikwikpg.tpl'));

      $payment_option->setModuleName('mobikwikpg');
      return [$payment_option];
    }

      private function _postValidation()
  {
    if (Tools::isSubmit('btnSubmit')) {
      if (!Tools::getValue('GATEWAY_MODE')) {
        $this->_postErrors[] = $this->trans('Gateway mode is required.', array(), 'Modules.Mobikwikpg.Admin');
      } elseif (!Tools::getValue('MERCHANT_IDENTIFIER') && Tools::getValue('MERCHANT_IDENTIFIER')) {
        $this->_postErrors[] = $this->trans('Merchant Identifier is required.', array(), 'Modules.Mobikwikpg.Admin');
      } elseif (!Tools::getValue('SECRET_KEY') && Tools::getValue('SECRET_KEY')) {
        $this->_postErrors[] = $this->trans('Secret Key is required.', array(), 'Modules.Mobikwikpg.Admin');
      }
    }
  }

  private function _postProcess()
  {
    if (Tools::isSubmit('btnSubmit')) {
      Configuration::updateValue('GATEWAY_MODE', Tools::getValue('GATEWAY_MODE'));
      Configuration::updateValue('MERCHANT_IDENTIFIER', Tools::getValue('MERCHANT_IDENTIFIER'));
      Configuration::updateValue('SECRET_KEY', Tools::getValue('SECRET_KEY'));
    }
    $this->_html .= $this->displayConfirmation($this->trans('Settings updated', array(), 'Admin.Notifications.Success'));
  }

  public function getContent()
  {
     $this->_html = '';

        if (Tools::isSubmit('btnSubmit')) {
            $this->_postValidation();
            if (!count($this->_postErrors)) {
                $this->_postProcess();
            } else {
                foreach ($this->_postErrors as $err) {
                    $this->_html .= $this->displayError($err);
                }
            }
        }

        $this->_html .= $this->_displayCheck();
        $this->_html .= $this->renderForm();

    return $this->_html;
  }

  public function renderForm()
  {

    $options = array(
      array(
          'id_option' => 'production',
          'name' => 'production'
          ),
        array(
          'id_option' => 'sandbox',
          'name' => 'sandbox'
          ),
        );

    $fields_form = array(
      'form' => array(
          'legend' => array(
            'title' => $this->trans('Mobikwik Payment Gateway details', array(), 'Modules.Mobikwikpg.Admin'),
            'icon' => 'icon-envelope'
            ),
          'input' => array(
            array(
              'type' => 'select',
              'label' => $this->trans('Gateway Mode', array(), 'Modules.Mobikwikpg.Admin'),
              'name' => 'GATEWAY_MODE',
              'required' => true,
              'options' => array(
                'query' => $options,
                'id' => 'id_option',
                'name' => 'name'
                )
              ),
            array(
                'type' => 'text',
                'label' => $this->trans('Merchant Identifier', array(), 'Modules.Mobikwikpg.Admin'),
                'name' => 'MERCHANT_IDENTIFIER',
                'required' => true
            ),
            array(
                'type' => 'text',
                'label' => $this->trans('Secret Key', array(), 'Modules.Mobikwikpg.Admin'),
                'name' => 'SECRET_KEY',
                'required' => true
              ),
            ),
          'submit' => array(
            'title' => $this->trans('Save', array(), 'Admin.Actions'),
            )
          ),
        );

    $helper = new HelperForm();
    $helper->show_toolbar = false;
    $helper->id = (int)Tools::getValue('id_carrier');
    $helper->identifier = $this->identifier;
    $helper->submit_action = 'btnSubmit';
    $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
    $helper->token = Tools::getAdminTokenLite('AdminModules');
    $helper->tpl_vars = array(
      'fields_value' => $this->getConfigFieldsValues(),
      );

    $this->fields_form = array();

    return $helper->generateForm(array($fields_form));
  }


  public function getConfigFieldsValues()
  {
    return array(
      'GATEWAY_MODE' => Tools::getValue('GATEWAY_MODE', Configuration::get('GATEWAY_MODE')),
      'SECRET_KEY' => Tools::getValue('SECRET_KEY', Configuration::get('SECRET_KEY')),
      'MERCHANT_IDENTIFIER' => Tools::getValue('MERCHANT_IDENTIFIER', Configuration::get('MERCHANT_IDENTIFIER')),
      );
  }


  private function _displayCheck()
  {
    return $this->display(__FILE__, './views/templates/hook/infos.tpl');
  }

  protected function mbkpginputs()
  {
    global $smarty, $cart;

    $merchant_identifier= Configuration::get('MERCHANT_IDENTIFIER');
    $secret_key= Configuration::get('SECRET_KEY');
    $gateway_mode= Configuration::get('GATEWAY_MODE');

    $orderId = 'ZPpresta'.rand(200,3000).'-'.$cart->id;
    $customer = new Customer($cart->id_customer);
    $address = new Address($cart->id_address_invoice);
    $state=new State($address->id_state);
    $country=new Country($address->id_country); 
    $firstName = $address->firstname;
    $lastName = $address->lastname;
    $pincode = $address->postcode;
    $email = $customer->email;
    $phone = $address->phone;
    $city = $address->city;;

    $id_currency = intval(Configuration::get('PS_CURRENCY_DEFAULT'));
    $currency = new Currency(intval($id_currency));
    $currency_code =$currency->iso_code;
    $orderAmount =floor($cart->getOrderTotal()*100);

    $return_url = $this->context->link->getModuleLink($this->name, 'validation', array(), true);

    $customer = new Customer($cart->id_customer);
    $address = new Address($cart->id_address_invoice);


    if ($gateway_mode == 'sandbox') {
      $action = "https://zaakstaging.zaakpay.com/api/paymentTransact/V8";
    }
    else {
      $action = "https://api.zaakpay.com/api/paymentTransact/V8";
    }

    $fields = array(
      'merchantIdentifier' => $merchant_identifier,
      'orderId' => $orderId,
      'buyerEmail' => $email,
      'returnUrl' => $return_url,
      'buyerFirstName' => $firstName,
      'buyerLastName' => $lastName,
      'buyerAddress' => $address->address1.' '.$address->address2 ,
      'buyerCity' => $city,
      'buyerState' => $state->name,
      'buyerCountry' => $country->iso_code,
      'buyerPincode' => $pincode,
      'buyerPhoneNumber' => $phone,
      'currency' => "INR",
      'amount' => $orderAmount,
      'purpose' => '1',
      'productDescription' => 'OrderId#'.$orderId,
      );

    $all = '';

    $checksumsequence= array("amount","bankid","buyerAddress",
        "buyerCity","buyerCountry","buyerEmail","buyerFirstName","buyerLastName","buyerPhoneNumber","buyerPincode",
        "buyerState","currency","debitorcredit","merchantIdentifier","merchantIpAddress","mode","orderId",
        "product1Description","product2Description","product3Description","product4Description",
        "productDescription","productInfo","purpose","returnUrl","shipToAddress","shipToCity","shipToCountry",
        "shipToFirstname","shipToLastname","shipToPhoneNumber","shipToPincode","shipToState","showMobile","txnDate",
        "txnType","zpPayOption");


    foreach($checksumsequence as $seqvalue) {
      if(array_key_exists($seqvalue,$fields)) {

        if(!$fields[$seqvalue]=="")
        {

          if($seqvalue != 'checksum')
          {
            $all .= $seqvalue;
            $all .="=";
            $all .= $fields[$seqvalue];
            $all .= "&";
          }
        }

      }
    }
    
    
    $checksum = $this->calculateChecksum($secret_key, $all);

    $fields = array_merge($fields, array(
                'checksum' => $checksum,
            ));

    $inputs = array();
    foreach ($fields as $k => $v)
    {
      $inputs[$k] = array(
        'name' => $k,
        'type' => 'hidden',
        'value' => $v,            
      );  
    } 
    
    return $inputs;
  }

  protected function calculateChecksum($secret_key, $all) {
    $hash = hash_hmac('sha256', $all , $secret_key);
    $checksum = $hash;
    return $checksum;
  }
}
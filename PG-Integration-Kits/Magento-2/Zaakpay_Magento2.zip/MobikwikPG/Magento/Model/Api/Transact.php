<?php
namespace MobikwikPG\Magento\Model\Api;

use \Magento\Payment\Model\Method\AbstractMethod;
use \Magento\Framework\App\ObjectManager;
use \MobikwikPG\Magento\Helper\Checksum as Checksum;
use \Magento\Directory\Helper\Data;



class Transact extends \Magento\Framework\DataObject
{

    protected $_checksum = null;

    protected $_globalMap = array(
        // commands
        'merchantIdentifier' => '',
        'orderId' => '',
        'returnUrl' => '',
        'buyerEmail' => '',
        'buyerFirstName' => '',
        'buyerLastName' => '',
        'buyerAddress' => '',
        'buyerCity' => '',
        'buyerState' => '',
        'buyerCountry' => '',
        'buyerPincode' => '',
        'buyerPhoneNumber' => '',
        'txnType' => '1',
        'zpPayOption' => '1',
        'mode' => '1',
        'currency' => 'USD',
        'amount' => '0',
        'merchantIpAddress' => '',
        'purpose' => '',
        'productDescription' => '',
        'product1Description' => '',
        'product2Description' => '',
        'product3Description' => '',
        'product4Description' => '',
        'shipToAddress' => '',
        'shipToCity' => '',
        'shipToState' => '',
        'shipToCountry' => '',
        'shipToPincode' => '',
        'shipToPhoneNumber' => '',
        'shipToFirstname' => '',
        'shipToLastname' => '',
        'txnDate' => '',
    );

    protected $_mandatory = array(
        'merchantIdentifier',
        'orderId',
        'buyerEmail',
        'buyerFirstName',
        'buyerLastName',
        'buyerAddress',
        'buyerCity',
        'buyerState',
        'buyerCountry',
        'buyerPincode',
        'buyerPhoneNumber',
        'txnType',
        'zpPayOption',
        'mode',
        'currency',
        'amount',
        'purpose',
        'merchantIpAddress',
        'productDescription',
        'txnDate'
    );

    protected $_scopeConfig;
    protected $_exception;

    
    protected $_transactionRepository;

    protected $_checkoutSession;
    protected $_transactionBuilder;

    
    protected $_urlBuilder;

    protected $_orderFactory;


    protected $_storeManager;
    protected $_countryFactory;

    public function __construct(
      \Magento\Framework\UrlInterface $urlBuilder,
      \Magento\Framework\Exception\LocalizedExceptionFactory $exception,
      \Magento\Sales\Api\TransactionRepositoryInterface $transactionRepository,
      \Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface $transactionBuilder,
      \Magento\Sales\Model\OrderFactory $orderFactory,
      \Magento\Store\Model\StoreManagerInterface $storeManager,
      \Magento\Framework\Model\Context $context,
      \Magento\Framework\Registry $registry,
      \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
      \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
      \Magento\Payment\Helper\Data $paymentData,
      \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
      \Magento\Payment\Model\Method\Logger $logger,
      \Magento\Directory\Helper\Data $helper,
      \Magento\Directory\Model\CountryFactory $countryFactory,
      \Magento\Checkout\Model\Session $checkoutSession,
      array $data = []
    ) {
      $this->_urlBuilder = $urlBuilder;
      $this->_exception = $exception;
      $this->_transactionRepository = $transactionRepository;
      $this->_transactionBuilder = $transactionBuilder;
      $this->_orderFactory = $orderFactory;
      $this->_storeManager = $storeManager;
      $this->_helper = $helper;
      $this->_countryFactory = $countryFactory;
      $this->_scopeConfig = $scopeConfig;
      $this->_checkoutSession = $checkoutSession;
      parent::__construct(
          $data
      );
    }

    private function _validateFields($fields) 
    {
        // mode is an exceptional case here as it may take a value '0' or 0 here so we handle that first
        if (!in_array($fields['mode'], array(0, 1))) {
            print('Zaakpay requires that the field mode can take only values 0 and 1');
        }
        unset($fields['mode']);
        foreach ($fields as $key=>$value) {
            if (in_array($key, $this->_mandatory) && !$value) {
                print('Zaakpay requires the field ' . $key . ' to be mandatory.');
            }
        }        
    }

    private function _buildRequestFields() 
    {   
        $fields = $this->_globalMap;
        $zaakpayConfig = $this->getZaakpayConfig();
        $order = $this->getOrder();
        $order_data = $order->getData();
        $billingAddress = $this->getBillingAddress();
        $shippingAddress = $this->getShippingAddress();
        $amount = floor($order->getGrandTotal() * 100);
        $currency = $order->getOrderCurrencyCode();
        //print_r($order->getIncrementId()); die();
        // merchant identifier
        $fields = array_merge($this->_globalMap, array(
            'merchantIdentifier' => $zaakpayConfig['merchant_identifier'],
            'orderId' => $order->getIncrementId(),
            'returnUrl' => $this->getReturnUrl(),
            'buyerEmail' => $order->getCustomerEmail(),
            'buyerFirstName' => $billingAddress->getFirstname(),
            'buyerLastName' => $billingAddress->getLastname(),
            'buyerAddress' => $this->_joinAddressStreet($billingAddress->getStreet()),
            'buyerCity' => $billingAddress->getCity(),
            'buyerState' => $billingAddress->getRegion(),
            'buyerCountry' => $this->_getCountryNameByCode($billingAddress->getCountryId()),
            'buyerPincode' => $billingAddress->getPostcode(),
            'buyerPhoneNumber' => $billingAddress->getTelephone(),
            'mode' => $zaakpayConfig['sandbox_mode'] ? 0 : 1,
            'currency' => $currency,
            'amount' => $amount,
            'merchantIpAddress' => $order->getRemoteIp(),
            'purpose' => '1',
            'productDescription' => 'Order Id #' . $order->getIncrementId(),
            'product1Description' => '',
            'product2Description' => '',
            'product3Description' => '',
            'product4Description' => '',
            'txnDate' => date('Y-m-d', strtotime($order->getCreatedAt())),
        ));
        // set the shipping address too if the order is not virtual
        if (!$order->getIsVirtual()) {
            $fields = array_merge($fields, array(
                'shipToAddress' => $this->_joinAddressStreet($shippingAddress->getStreet()),
                'shipToCity' => $shippingAddress->getCity(),
                'shipToState' => $shippingAddress->getRegion(),
                'shipToCountry' => $this->_getCountryNameByCode($shippingAddress->getCountryId()),
                'shipToPincode' => $shippingAddress->getPostcode(),
                'shipToPhoneNumber' => $shippingAddress->getTelephone(),
                'shipToFirstname' => $shippingAddress->getFirstname(),
                'shipToLastname' => $shippingAddress->getLastname(),
            ));
        }
        return $fields;
    }

    /**
     * Method to return the country name by the country code
     */
    private function _getCountryNameByCode($code) 
    {   //print_r($code);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $countryModel = $objectManager->create('\Magento\Directory\Model\Country')->loadByCode($code);
        return ucfirst($countryModel->getName());        
    }

    /**
     * Method to convert the amount to INR
     * @param decimal $amount
     * @param String $currency
     */
    private function _convertAmount($amount, $currencyCode) 
    {   
	    $backamount = 0 ;
        if ($currencyCode == 'INR' ) {
            $backamount = floor($amount * 100);           
        }
		if (($currencyCode != 'INR') && ($currencyCode != 'USD')) {
            $amount = $this->_helper->currencyConvert($amount, $currencyCode, 'INR');
			$backamount = floor($amount * 100);            
        }
		if ($currencyCode == 'USD') {
            $backamount = floor($amount * 100);
        }
		return $backamount;
        
    }

    /**
     * Method to join Street 1 and Street 2 in an address to a single string
     * @param mixed $address (String|Array)
     * @return String $address
     */
    private function _joinAddressStreet($address) 
    {
        if (is_array($address)) {            
            $address = array_map('trim', $address);
            $joined = implode(" ", $address);
            return substr($joined, 0, 30);
        }
        return $address;
    }

    /**
     * Method to concatenate the fields into a string
     * using which the checksum will be creaeted
     * @param Array $fields
     * @param String
     */
    public function _concatFields($fields) 
    {
        unset($fields['checksum']);
        #ksort($fields);
        return "'" . implode("'", $fields) . "'";
    }

    public function getRequestFields() 
    {
        $fields = $this->_buildRequestFields();
        // pass it through validate so that an exception is thrown
        $this->_validateFields($fields);
        $all = Checksum::getAllParams($fields);
	error_log("Logging stripped params : " . $all);
        
        $checksum = Checksum::calculateChecksum($this->_scopeConfig->getValue('payment/mobikwik_gateway/secret_key'), $all);
		error_log("Logging stripped params : " . $all);
	error_log('Logging key used to produce checksum : ' . $this->_scopeConfig->getValue('payment/mobikwik_gateway/secret_key'));
	error_log('Logging checksum : ' . $checksum);
        $this->_checksum = $checksum;
        // var_dump($all, $checksum);
        #ksort($fields);
        // first sort by key and then append checksum in the end 
        $fields['checksum'] = $checksum;
        return $fields;
    }

    public function getZaakpayChecksum() 
    {
        return $this->_checksum;
    }
}


<?php

namespace MobikwikPG\Magento\Model;

use MobikwikPG\Magento\Model\Api\Transact as TransactAPI;
use MobikwikPG\Magento\Model\Api\Request as RequestAPI;
use MobikwikPG\Magento\Model\Api\Update as UpdateAPI;
use MobikwikPG\Magento\Model\Api\Check as CheckAPI;
use \MobikwikPG\Magento\Helper\Checksum;

class Transact extends \Magento\Payment\Model\Method\AbstractMethod {

    const CODE = 'mobikwik_gateway';

    // protected $_canAuthorize            = true;
    protected $_canCapture              = true;
    protected $_isInitializeNeeded      = true;
    protected $_canUseInternal          = false;
    protected $_canUseForMultishipping  = false;
    protected $_canVoid                 = true;
    protected $_canRefund               = true;
    protected $_canUseCheckout          = true;
    protected $_code                    = self::CODE;

    protected $_scopeConfig;
    
    protected $_exception;

    protected $_checkoutSession;
    protected $_transactionRepository;
    protected $_orderFactory;

    protected $_transactionBuilder;
    protected $_payment;

    
    protected $_urlBuilder;
    protected $_order;
    protected $_logger;

    protected $_storeManager;
    protected $_quoteManagement;

    public function __construct(
      \Magento\Framework\UrlInterface $urlBuilder,
      \Magento\Framework\Exception\LocalizedExceptionFactory $exception,
      \Magento\Sales\Api\TransactionRepositoryInterface $transactionRepository,
      \Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface $transactionBuilder,
      \Magento\Sales\Model\OrderFactory $orderFactory,
      \Magento\Store\Model\StoreManagerInterface $storeManager,
      \Magento\Framework\Model\Context $context,
      \Magento\Framework\Registry $registry,
      \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
      \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
      \Magento\Payment\Helper\Data $paymentData,
      \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
      \Magento\Payment\Model\Method\Logger $logger,
      \Magento\Checkout\Model\Session $checkoutSession,
      \Magento\Quote\Api\CartManagementInterface $quoteManagement,
      //\Psr\Log\LoggerInterface $logger,
      \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
      \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
      array $data = []
    ) {
      $this->_urlBuilder = $urlBuilder;
      $this->_exception = $exception;
      $this->_transactionRepository = $transactionRepository;
      $this->_transactionBuilder = $transactionBuilder;
      $this->_orderFactory = $orderFactory;
      $this->_storeManager = $storeManager;
      $this->_checkoutSession = $checkoutSession;
      $this->_scopeConfig = $scopeConfig;
      $this->_logger = $logger;
      $this->_quoteManagement = $quoteManagement;

      parent::__construct(
          $context,
          $registry,
          $extensionFactory,
          $customAttributeFactory,
          $paymentData,
          $scopeConfig,
          $logger,
          $resource,
          $resourceCollection,
          $data
      );
    }

    /**
     * Url to which the post form will be submitted
     * and the user will be redirected
     * @param String Url
     */


    public function getPostForm() {

        $fields = self::getCheckoutFormFields();
        $form = '<form id="mobikwik_checkout" method="POST" action="' . self::getZaakpayTransactAction() . '">';
        foreach($fields as $key => $value) {
          $form .= '<input type="hidden" name="'.$key.'" value="'.$value.'" />'."\n";
        }
        $form .= '</form>';
        $html = '<html><body>';
        //$html .= $this->__('You will be redirected to the Zaakpay website in a few seconds.');
        $html .= $form;
        $html.= '<script type="text/javascript">document.getElementById("mobikwik_checkout").submit();</script>';
        $html.= '</body></html>';
        return $html;

    }
    public function getZaakpayTransactAction() 
    {
        return 'https://zaakstaging.zaakpay.com/api/paymentTransact/V8';
    }

    /**
     * Url for calling the update api
     * @param String Url
     */
    public function getZaakpayUpdateApiUrl() 
    {
        return 'https://api.zaakpay.com/updatetransaction';
    }

    /**
     * Instantiate state and set it to state object
     * @param string $paymentAction
     * @param \Magento\Framework\DataObject
     */
    public function initialize($paymentAction, $stateObject)
    {   
 
        $state = \Magento\Sales\Model\Order::STATE_PENDING_PAYMENT;
        $stateObject->setState($state);
        $stateObject->setStatus('pending_payment');
        $stateObject->setIsNotified(false);
    }

    /**
     * Method to get the form fields with the relevant fields filled in
     * @return Array of form fields in the name=>value form 
     */
    public function getCheckoutFormFields()
    {   
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
        $session = $objectManager->get('\Magento\Checkout\Model\Session');
        $orderIncrementId = $session->getLastRealOrderId();

        $order = $objectManager->create('\Magento\Sales\Model\Order')->loadByIncrementId($orderIncrementId);
      
        // add cart totals and line items
        $session->setZaakpayOrderId($orderIncrementId);
        $session->setLastSuccessQuoteId($order->getQuoteId());
        $session->setLastQuoteId($order->getQuoteId());
        $session->setLastOrderId($order->getIncrementId());
        $api = $objectManager->create('MobikwikPG\Magento\Model\Api\Transact')->setConfig($this->getConfig());
       
        $api->setOrderId($orderIncrementId)
            ->setCurrencyCode($order->getBaseCurrencyCode())
            ->setOrder($order)
            ->setZaakpayConfig($this->_scopeConfig->getValue('payment/mobikwik_gateway'))
            ->setReturnUrl($this->_urlBuilder->getUrl('mobikwikpg/checkout/response'));
          // export address
        $isOrderVirtual = $order->getIsVirtual();
        $api->setBillingAddress($order->getBillingAddress());
        if ($isOrderVirtual) {
            $api->setNoShipping(true);
        } elseif ($order->getShippingAddress()) {
            $api->setShippingAddress($order->getShippingAddress());
        }
          $result = $api->getRequestFields();
          

          $session->setZaakpayChecksum($api->getZaakpayChecksum());
          return $result;
      }  

    public function zaakpaySuccessOrderState($order_status) 
    {
        switch ($order_status) {
        case "processing":
            $state = \Magento\Sales\Model\Order::STATE_PROCESSING;
            break;
        case "complete":
            $state = \Magento\Sales\Model\Order::STATE_COMPLETE;
            break;
        case "closed":
            $state = \Magento\Sales\Model\Order::STATE_CLOSED;
            break;
        case "canceled":
            $state = \Magento\Sales\Model\Order::STATE_CANCELED;
            break;
        case "holded":
            $state = \Magento\Sales\Model\Order::STATE_HOLDED;
            break;
        case "pending":
        case "success":             
            $state = \Magento\Sales\Model\Order::STATE_COMPLETE;
    break;
        default:
            $state = \Magento\Sales\Model\Order::STATE_PENDING_PAYMENT;
        }
        return $state;
    }

    public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount) 
    {
        $order = $payment->getOrder();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $api = $objectManager->create('MobikwikPG\Magento\Model\Api\Update');
        $api->send($order->getIncrementId(), UpdateAPI::STATUS_SETTLED, 'payment captured');        
        if ($api->getResponseCode() == 196) {
             throw new \Magento\Framework\Exception\LocalizedException(__('Online Capture failed. Zaakpay Update Api responded Response Code: '.$api->getResponseCode() . ' Message: ' . $api->getResponseDescription()));
            $this->_logger->debug('Zaakpay update api failure: orderId: '.$order->getIncrementId() . ', responseCode: ' . $api->getResponseCode(). ', responseDescription: ' . $api->getResponseDescription());
        }
    }

    public function cancel(\Magento\Payment\Model\InfoInterface $payment) 
    {
        $order = $payment->getOrder();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $api = $objectManager->create('MobikwikPG\Magento\Model\Api\Update');
        $api->send($order->getIncrementId(), UpdateAPI::STATUS_CANCELLED, 'order cancelled');
		//*****************************************************//
		$order_check = $payment->getOrder();
        $api_check = $objectManager->create('MobikwikPG\Magento\Model\Api\Check');
        $api_check->check($order_check->getIncrementId());
		$response_code = $api_check->getResponseCode();
		if(!$response_code == 213 )	// transaction already cancelled by merchant
		{
		   if( !in_array($api->getResponseCode(), array(243,230)))
		{
             throw new \Magento\Framework\Exception\LocalizedException(__('Request could not be completed since Zaakpay Update Api responded with update failure. Response Code: '.$api->getResponseCode()));
            $this->_logger->info('Zaakpay update api failure: orderId: '.$order->getIncrementId() . ', responseCode: ' . $api->getResponseCode(). ', responseDescription: ' . $api->getResponseDescription());
        }}
    }

    public function void(\Magento\Payment\Model\InfoInterface $payment) {
        $order = $payment->getOrder();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $api = $objectManager->create('MobikwikPG\Magento\Model\Api\Update');
        $api->send($order->getIncrementId(), UpdateAPI::STATUS_CANCELLED, 'order void');        
        if (!in_array($api->getResponseCode(), array(226, 198, 213,243))) {
             throw new \Magento\Framework\Exception\LocalizedException(__('Request could not be completed since Zaakpay Update Api responded with update failure. Response Code: '.$api->getResponseCode()));
            $this->_logger->info('Zaakpay update api failure: orderId: '.$order->getIncrementId() . ', responseCode: ' . $api->getResponseCode(). ', responseDescription: ' . $api->getResponseDescription());
        }
    }

    // refund cannot be consumed as there is no api to capture funds
    public function refund(\Magento\Payment\Model\InfoInterface $payment, $amount) 
    {
        $this->_logger->info('refund is getting called');
    }

    // call the check transaction api to show the current status
    public function checkStatus(\Magento\Payment\Model\InfoInterface $payment) 
    {
        $order = $payment->getOrder();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $api = $objectManager->create('MobikwikPG\Magento\Model\Api\Check');
        $api->check($order->getIncrementId());
        $status = $api->getResponseDescription();
        return $status;
    }

}

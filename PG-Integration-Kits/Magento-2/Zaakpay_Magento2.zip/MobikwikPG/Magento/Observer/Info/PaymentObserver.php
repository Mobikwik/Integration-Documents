<?php
namespace MobikwikPG\Magento\Observer\Info;

use \Magento\Framework\App\ObjectManager;

class PaymentObserver {

    public function execute(\Magento\Framework\Event\Observer $observer) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $session = $objectManager->get('MobikwikPG\Magento\Model\MobikwikSession');
        $payment = $observer->getPayment();
        $payment_method = $observer->getPayment()->getMethodInstance();
        $orderId = $payment->getOrder()->getIncrementId();
        if ($payment_method->getCode() == 'mobikwik_gateway') {
            
            $status = $payment_method->checkStatus($payment);  
            $observer->getTransport()->setData('Latest Zaakpay Status', $status);            
        }
        return $this;
    }

}
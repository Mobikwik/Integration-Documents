<?php
	
	namespace MobikwikPG\Magento\Controller\Checkout;

	use \MobikwikPG\Magento\Helper\Checksum;

	class Response extends \Magento\Framework\App\Action\Action
	{

		protected $_scopeConfig;
		protected $_storeManager;
		protected $_request;
		protected $_checkoutSession;
    protected $_resultJsonFactory;
    protected $_logger;
    protected $_messageManager;

    public function __construct(
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
    \Magento\Store\Model\StoreManagerInterface $storeManager,
    \Magento\Framework\App\Action\Context $context,
    \Magento\Checkout\Model\Session $checkoutSession,
    \Magento\Sales\Model\OrderFactory $orderFactory,
    \Magento\Framework\Message\ManagerInterface $messageManager,
    \Psr\Log\LoggerInterface $logger
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
        $this->_checkoutSession = $checkoutSession;
        $this->_logger = $logger;
        $this->_messageManager = $messageManager;
        parent::__construct($context);
    }
		public function execute() 
		{
		// actual processing
			$postdata = $this->getRequest()->getPost();
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
      $session = $objectManager->get('\Magento\Checkout\Model\Session');
			$session->setQuoteId($session->getZaakpayQuoteId(true));
			$checksumReceived = $postdata['checksum'];
			$allParamsReceived = \MobikwikPG\Magento\Helper\Checksum::getAllResponseParams($postdata);

			$checksumCalculated = \MobikwikPG\Magento\Helper\Checksum::calculateChecksum($this->_scopeConfig->getValue('payment/mobikwik_gateway/secret_key'), $allParamsReceived);
			error_log("Logging response params : " . $allParamsReceived);
			error_log('Logging checksum : ' . $checksumCalculated);
			if ($checksumReceived !== $checksumCalculated) {
				if ($session->getLastRealOrderId()) {
					$order = $objectManager->create('\Magento\Sales\Model\Order')->loadByIncrementId($postdata['orderId']);
					if ($order->getId()) {
					  $order->cancel()->save();
					}
				}
				$er = 'Checksum does not match. This response has been compromised. However, transaction might have been successful.';
				$this->_messageManager->addErrorMessage($er);
				$this->_redirect('checkout/onepage/failure');
				return;
			}
			// success
			if ($this->_validateResponse()) {
				$objectManager->get('\Magento\Checkout\Model\Session')->getQuote()->setIsActive(false)->save();
				// load the order and change the order status
				$zaakpay = $objectManager->create('MobikwikPG\Magento\Model\Transact');
				$state = $zaakpay->zaakpaySuccessOrderState('success');
				$order = $objectManager->create('\Magento\Sales\Model\Order')->loadByIncrementId($postdata['orderId']);

				$order->setData('state', $state);
				$order->setStatus($state);            
				$payment = $order->getPayment();
				$transaction = $objectManager->create('Magento\Sales\Model\Order\Payment\Transaction');
				$dummy_txn_id = 'ZP_'.$postdata['orderId'];
				$payment->setTransactionId($dummy_txn_id)       
        ->setPreparedMessage($postdata['responseDescription'])
        ->setShouldCloseParentTransaction(true)
        ->setIsTransactionClosed(0)
        ->setTxnType(\Magento\Sales\Model\Order\Payment\Transaction::TYPE_AUTH)
				->setAdditionalInformation(['mobikwikpg'])
        ->registerCaptureNotification(
            $postdata['amount'],
            true 
        )
        ->save();
				$order->save();
        try
        {
          $emailSender = $objectManager->create('\Magento\Sales\Model\Order\Email\Sender\OrderSender');
          $emailSender->send($order);
        } catch (Exception $ex) {  }
           
				$this->_redirect('checkout/onepage/success', ['_secure' => true]);
				} 
        else {
				// failure/cancel
					if ($session->getLastRealOrderId()) {
						$order = $objectManager->create('\Magento\Sales\Model\Order')->loadByIncrementId($postdata['orderId']);
						if ($order->getId()) {
							$order->cancel()->save();
						}
					}
					$er = 'Zaakpay could not process your request because of the error "'.$postdata['responseDescription'] . '"'; 
					$this->_messageManager->addErrorMessage($er);
					$this->_redirect('checkout/onepage/failure');
				}
		}

		/**
		* Verify the response coming into the server
		* @return boolean
		*/
		protected function _validateResponse() 
		{
			$postdata = $this->getRequest()->getPost();
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
      $session = $objectManager->get('\Magento\Checkout\Model\Session');
			$flag = False;
			error_log('Response Code is ' . $postdata['responseCode']);
			if ((int)$postdata['responseCode'] == 100) {
				$flag = True;
			}
			return $flag;
		}
	}
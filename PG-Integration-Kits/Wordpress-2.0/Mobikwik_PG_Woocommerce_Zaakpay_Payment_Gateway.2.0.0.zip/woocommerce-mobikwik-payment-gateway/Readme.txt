								Woocommerce Zaakpay Payment Gateway 

Zaakpay is an Indian payment which will accept the payment from any types of credit and debit card. 



									Requirement	

This plugin required Woocommerce 2.0 or later. and also required the zaakpay merchant identifier or merchant no and secret key provided by zaakpay.   




									Installation

Please use the following link for plugin installation https://wordpress.org/plugins/woocommerce-payment-gateway/#installation. This plugin required a zaakpay account please follow the link https://www.zaakpay.com. once you have activated the plugin you have to enable the Woocommerce Zaakpay Payment Gateway under the woocommerce->settings->Payments section.  




								  Frequently Asked Questions 


1.Where we find the merchant identifier?
Ans. You can find the merchant identifier or merchant id from developers tab in zaakpay.com. 

2.Is zaakpay registration is required to use this plugin?
Ans. Yes you have to register with zaakpay they didn't charge for registration and you can also test with the zaakpay's registered account credential without going 	 live.


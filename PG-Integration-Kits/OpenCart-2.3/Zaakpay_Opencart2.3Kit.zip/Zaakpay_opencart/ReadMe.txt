Instructions

1)	Copy the Zaakpay.php file to upload\admin\controller\extension\payment\Zaakpay.php
2)	Copy the Zaakpay.php file to upload\admin\language\english\extension\payment\ Zaakpay.php
3)	Copy the Zaakpay.tpl file to upload\admin\view\template\extension\payment\ Zaakpay.tpl
4)	Copy the Zaakpay.php file to upload\catalog\controller\extension\payment\ Zaakpay.php
5)	Copy the Zaakpay.php file to upload\catalog\language\english\common\ Zaakpay.php
6)	Copy the Zaakpay.php file to upload\catalog\language\english\extension\payment\ Zaakpay.php
7)	Copy the Zaakpay.php file to upload\catalog\model\extension\payment\ Zaakpay.php
8)	Copy the response.php file to \upload\catalog\controller\common\response.php
9)	Copy the response.tpl file to upload\catalog\view\theme\default\template\common\response.tpl
10)	Copy the Zaakpay.tpl file to upload\catalog\view\theme\default\template\extension\payment\ Zaakpay.tpl
11)	Enter your MerchantIdentifier , Secret Key and select the Mode from the Zaakpay Payment Method control panel & Enable it.


IMP:*  

By Default the link will hit to our staging enviroment. any transaction made there will include an real money. 
This staging enviroment is only for testing purpose only. 
The testing credentials are marked in our Doc. for reference .


After you complete all your testing, upload->catalog->controller->extension->payment->Zaakpay.php
1. Change the action link with "https://api.zaakpay.com/api/paymentTransact/V7"
2. Change  your merchant Identifier and secret key from the admin panel.



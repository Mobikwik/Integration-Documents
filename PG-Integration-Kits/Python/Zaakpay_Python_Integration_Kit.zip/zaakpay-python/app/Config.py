#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 11 14:36:09 2020

@author: harshpujari
"""

class Config:
    
	ZAAKPAY_MERCHANT_IDENTIFIER = "b6415a6443604ec59644a70c8b25a0f6" #Get your merchant identifier on Zaakpay.com

	ZAAKPAY_SECRET_KEY = "0678056d96914a8583fb518caf42828a" ; #Get your secret key on Zaakpay.com

	#Api URL
	ENVIRONMENT = "https://zaakstaging.zaakpay.com" ; #For Live transaction use https://api.zaakpay.com

	#Payment processing URL's
	TRANSACTION_API_URL = "/api/paymentTransact/V8" 

	#Transaction update URL's
	UPDATE_API_URL = "/updatetransaction" 

	#Transaction check status URL's
	TRANSACTION_STATUS_API_URL = "/checkTxn?v=5" 
    
    #To see the demo
	DEMO = True ; #Change this with your response file

	#Url for test response file
	RETURN_URL = "" ; #Change this with your response file
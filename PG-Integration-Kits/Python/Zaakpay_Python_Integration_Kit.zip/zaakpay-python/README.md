# Zaakpay Python Integration Kit

 1. The ZaakPay Python integration kit consists of four files.
	
	- Transaction.py
	  This will generate the request param for triggering different Zaakpay's API. 
	
	- RequestParameters.py
	  This will provide the mandatory/optional request parameters for API request you can skip this by passing
	  all the parameters as function arguments.

	- ChecksumGenerator.py
	  This will generate checksum.

	- Config.py
	  This will provide the configuration for transaction processing/update.

 2. Open Config.py and verify the below values.
	- ENVIRONMENT ( https://zaakstaging.zaakpay.com ( Staging ) or https://api.zaakpay.com ( Production ) )
	- RETURN_URL ( Callback URL on which Zaakpay will send the response , "" will send callback to the default test page of zaakpay for staging environment )



 

package com.mobikwik.zaakpaysdktest;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.mobikwik.mobikwikpglib.PaymentCheckout;
import com.mobikwik.mobikwikpglib.lib.transactional.TransactionData;
import com.mobikwik.mobikwikpglib.lib.transactional.TransactionDataBuilder;
import com.mobikwik.mobikwikpglib.lib.transactional.TransactionResponse;
import com.mobikwik.mobikwikpglib.utils.Enums;
import com.mobikwik.mobikwikpglib.utils.Utils;

import java.math.BigInteger;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Created by Mayank on 21/06/2019.
 */
public class MainActivity extends AppCompatActivity implements PaymentCheckout.ZaakPayPaymentListener {


    private static final String TAG = "SDK_TEST_APP";
    private EditText txtAmount;
    private EditText txtMerchantId;
    private EditText txtMerchantName;
    private EditText txtIconUrl;
    private EditText txtReturnUrl;
    private EditText txtChecksum;
    private EditText txtChecksumPO;
    private EditText txtOrderId;
    private EditText txtEmail;
    private EditText txtPhone;
    private EditText txtBuyerFirstName;
    private EditText txtBuyerLastName;
    private EditText txtBuyerAddress;
    private EditText txtBuyerCity;
    private EditText txtBuyerState;
    private EditText txtBuyerCountry;
    private EditText txtBuyerPincode;
    private EditText txtShipToFirstName;
    private EditText txtShipToLastName;
    private EditText txtShipToAddress;
    private EditText txtShipToCity;
    private EditText txtShipToState;
    private EditText txtShipToCountry;
    private EditText txtShipToPincode;
    private EditText txtShipToPhone;
    private EditText txtCurrency;
    private EditText txtProductDescription;
    private EditText txtProduct1Description;
    private EditText txtProduct2Description;
    private EditText txtProduct3Description;
    private EditText txtProduct4Description;
    private Spinner spinnerEnvironment;

    private String checksumTransact;
    private String checksumPO;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerEnvironment = findViewById(R.id.spinner_environment);
        spinnerEnvironment.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Enums.Environment.values()));

        //randomly adding current time as orderId
        txtOrderId = findViewById(R.id.edit_text_orderid);
        txtOrderId.setText(String.valueOf(System.currentTimeMillis()));


        txtEmail = findViewById(R.id.edit_text_email);
        txtPhone = findViewById(R.id.edit_text_phone);
        txtAmount = findViewById(R.id.edit_text_amount);
        txtMerchantId = findViewById(R.id.edit_text_merchant_id);
        txtMerchantName = findViewById(R.id.edit_text_merchant_name);
        txtIconUrl = findViewById(R.id.edit_text_merchant_icon);
        txtReturnUrl = findViewById(R.id.edit_text_return_url);
        txtChecksum = findViewById(R.id.edit_text_checksum);

        txtChecksumPO = findViewById(R.id.edit_text_checksum_po);

        txtBuyerFirstName = findViewById(R.id.edit_text_buyer_fname);
        txtBuyerLastName = findViewById(R.id.edit_text_buyer_lname);
        txtBuyerAddress = findViewById(R.id.edit_text_buyer_address);
        txtBuyerCity = findViewById(R.id.edit_text_buyer_city);
        txtBuyerState = findViewById(R.id.edit_text_buyer_state);
        txtBuyerCountry = findViewById(R.id.edit_text_buyer_country);
        txtBuyerPincode = findViewById(R.id.edit_text_buyer_pincode);

        txtShipToFirstName = findViewById(R.id.edit_text_shipto_fname);
        txtShipToLastName = findViewById(R.id.edit_text_shipto_lname);
        txtShipToAddress = findViewById(R.id.edit_text_shipto_address);
        txtShipToCity = findViewById(R.id.edit_text_shipto_city);
        txtShipToState = findViewById(R.id.edit_text_shipto_state);
        txtShipToCountry = findViewById(R.id.edit_text_shipto_country);
        txtShipToPincode = findViewById(R.id.edit_text_shipto_pincode);
        txtShipToPhone = findViewById(R.id.edit_text_shipto_phone);

        txtCurrency = findViewById(R.id.edit_text_currency);
        txtProductDescription = findViewById(R.id.edit_text_product_description);
        txtProduct1Description = findViewById(R.id.edit_text_product1_description);
        txtProduct2Description = findViewById(R.id.edit_text_product2_description);
        txtProduct3Description = findViewById(R.id.edit_text_product3_description);
        txtProduct4Description = findViewById(R.id.edit_text_product4_description);
    }

    public void onButtonClick(View view) {
        setCheckSums();

        BigInteger bigIntegerAmount = null;
        String amtTxt = txtAmount.getText().toString();
        if (!amtTxt.isEmpty()) {
            bigIntegerAmount = new BigInteger(amtTxt);
        }

//        TransactionData transactionData = setManadatoryParams(bigIntegerAmount);

        TransactionData transactionData = setAllParams(bigIntegerAmount);

        Enums.Environment env = (Enums.Environment) spinnerEnvironment.getSelectedItem();
        Log.d(TAG, "ENV = " + env.toString());

        transactionData.setEnvironment(env);

        Log.d(TAG, "txtAmount=" + txtAmount.getText().toString());
        Log.d(TAG, "txtChecksum=" + txtChecksum.getText().toString());
        Log.d(TAG, "txtChecksumPO=" + txtChecksumPO.getText().toString());
        Log.d(TAG, "txtMerchantId=" + txtMerchantId.getText().toString());
        Log.d(TAG, "txtMerchantName=" + txtMerchantName.getText().toString());
        Log.d(TAG, "txtIconUrl=" + txtIconUrl.getText().toString());
        Log.d(TAG, "txtOrderid=" + txtOrderId.getText().toString());
        Log.d(TAG, "txtReturnUrl=" + txtReturnUrl.getText().toString());
        Log.d(TAG, "txtEmail=" + txtEmail.getText().toString());
        Log.d(TAG, "txtPhoneNumber=" + txtPhone.getText().toString());


        PaymentCheckout paymentCheckout = new PaymentCheckout(this);
        paymentCheckout.startPayment(transactionData);

    }

    private TransactionData setAllParams(BigInteger bigIntegerAmount) {
        TransactionData transactionData = new TransactionData();

        transactionData.setAmount(bigIntegerAmount);
        transactionData.setChecksum(txtChecksum.getText().toString());
        transactionData.setChecksumPO(txtChecksumPO.getText().toString());
        transactionData.setMerchantId(txtMerchantId.getText().toString());
        transactionData.setMerchantName(txtMerchantName.getText().toString());
        transactionData.setMerchantIconUrl(txtIconUrl.getText().toString());
        transactionData.setOrderId(txtOrderId.getText().toString());
        transactionData.setReturnUrl(txtReturnUrl.getText().toString());
        transactionData.setUserEmail(txtEmail.getText().toString());
        transactionData.setUserPhoneNumber(txtPhone.getText().toString());

        transactionData.setBuyerFirstName(txtBuyerFirstName.getText().toString());
        transactionData.setBuyerLastName(txtBuyerLastName.getText().toString());
        transactionData.setBuyerAddress(txtBuyerAddress.getText().toString());
        transactionData.setBuyerCity(txtBuyerCity.getText().toString());
        transactionData.setBuyerState(txtBuyerState.getText().toString());
        transactionData.setBuyerCountry(txtBuyerCountry.getText().toString());
        transactionData.setBuyerPincode(txtBuyerPincode.getText().toString());

        transactionData.setShipToFirstName(txtShipToFirstName.getText().toString());
        transactionData.setShipToLastName(txtShipToLastName.getText().toString());
        transactionData.setShipToAddress(txtShipToAddress.getText().toString());
        transactionData.setShipToCity(txtShipToCity.getText().toString());
        transactionData.setShipToState(txtShipToState.getText().toString());
        transactionData.setShipToCountry(txtShipToCountry.getText().toString());
        transactionData.setShipToPincode(txtShipToPincode.getText().toString());
        transactionData.setShipToPhone(txtShipToPhone.getText().toString());

        transactionData.setCurrency(txtCurrency.getText().toString());
        transactionData.setProductDescription(txtProductDescription.getText().toString());
        transactionData.setProduct1Description(txtProduct1Description.getText().toString());
        transactionData.setProduct2Description(txtProduct2Description.getText().toString());
        transactionData.setProduct3Description(txtProduct3Description.getText().toString());
        transactionData.setProduct4Description(txtProduct4Description.getText().toString());
        return transactionData;
    }

    private TransactionData setManadatoryParams(BigInteger bigIntegerAmount) {
        TransactionDataBuilder transactionDataBuilder = new TransactionDataBuilder()
                .withAmount(bigIntegerAmount)
                .withChecksum(checksumTransact)
                .withChecksumPO(checksumPO)
                .withCurrency("INR")
                .withOrderId(txtOrderId.getText().toString())
                .withUserEmail(txtEmail.getText().toString())
                .withReturnUrl(txtReturnUrl.getText().toString())
                .withMerchantIconUrl(txtIconUrl.getText().toString())
                .withMerchantName(txtMerchantName.getText().toString())
                .withMerchantId(txtMerchantId.getText().toString())
                .withUserPhoneNumber(txtPhone.getText().toString())
                .withEnvironment(Enums.Environment.STAGING);
        return transactionDataBuilder.build();
    }



    private void showAlertDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Transaction Response");
        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }

    private void setCheckSums() {

        String ip = Utils.getLocalIpAddress();
        String date = Utils.getCurrentDate();

        BigInteger amtInt = null;
        String amtTxt = txtAmount.getText().toString();
        if (!amtTxt.isEmpty()) {
            amtInt = new BigInteger(amtTxt);
        }

        String paramsForTransactChecksum = "'" + txtMerchantId.getText().toString() + "''" +
                txtOrderId.getText().toString() + "''0''INR''" + amtInt +
                "''" + ip + "''" + date + "'";

        Log.d(TAG, paramsForTransactChecksum);

        String paramsForPOChecksum = "merchantIdentifier=" + txtMerchantId.getText().toString() + "&email=" + txtEmail.getText().toString();

        //staging key
        String secretKey = "0678056d96914a8583fb518caf42828a";

        try {
            checksumTransact = createChecksum(secretKey, paramsForTransactChecksum);

            checksumPO = createChecksum(secretKey, paramsForPOChecksum);

            Log.d(TAG, "setCheckSums: " + checksumTransact);
            Log.d(TAG, "setCheckSums: " + checksumPO);

            txtChecksum.setText(checksumTransact);
            txtChecksumPO.setText(checksumPO);
        } catch (Exception ex) {
            Log.d(TAG, "checksum exception");
        }
    }

    public static String createChecksum(String secretKey, String allParamValueExceptChecksum) throws Exception {
        Log.d(TAG, "In cryptoUtils createChecksum function");
        byte[] dataToEncryptByte = allParamValueExceptChecksum.trim().getBytes();
        SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(secretKeySpec);
        byte[] checksumCalculatedByte = mac.doFinal(dataToEncryptByte);
        return toHex(checksumCalculatedByte);
    }

    private static String toHex(byte[] bytes) {
        StringBuilder buffer = new StringBuilder(bytes.length * 2);
        String str;
        for (Byte b : bytes) {
            str = Integer.toHexString(b);
            int len = str.length();
            if (len == 8) {
                buffer.append(str.substring(6));
            } else if (str.length() == 2) {
                buffer.append(str);
            } else {
                buffer.append("0" + str);
            }
        }
        return buffer.toString();
    }
    @Override
    public void onPaymentFailure(String responseCode, String responseDescription) {
        String sb = ("\nStatuscode : " + responseCode) +
                "\nStatusmessage : " + responseDescription;
        showAlertDialog(sb);
    }

    @Override
    public void onPaymentSuccess(TransactionResponse response) {
        String sb = ("\nStatuscode : " + response.getResponseCode()) +
                "\nStatusmessage : " + response.getResponseDescription();
        showAlertDialog(sb);

    }
}

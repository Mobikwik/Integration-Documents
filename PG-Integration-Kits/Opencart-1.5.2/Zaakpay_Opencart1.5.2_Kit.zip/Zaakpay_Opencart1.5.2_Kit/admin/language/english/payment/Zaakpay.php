<?php
// Heading
$_['heading_title']   = 'Zaakpay';

// Entry
$_['text_payment']		            	   = 'Payment';
$_['entry_status']                         = 'Status:';
$_['text_success']      				   = 'Success: You have modified Zaakpay payment module!';
$_['text_Zaakpay']	            		   = '<a onclick="window.open(\'http://www.zaakpay.com\');"><img src="view/image/payment/Zaakpay.png" alt="Zaakpay" title="Zaakpay" style="border: 1px solid #EEEEEE;" height=40 /></a>';

$_['merchantIdentifier']		 		   = 'Merchant Identifier:';
$_['secret_key']					 	   = 'Secret Key: ';
$_['mode']						   		   = 'Test Mode: ';
$_['merchantIpAddress']     			   = 'Merchant IP Address:';
$_['log']     							   = 'Do you want to log:';
$_['entry_geo_zone']   					   = 'Geo Zone:';
// Error
$_['error_permission']                     = 'Warning: You do not have permission to modify payment Zaakpay!';

?>

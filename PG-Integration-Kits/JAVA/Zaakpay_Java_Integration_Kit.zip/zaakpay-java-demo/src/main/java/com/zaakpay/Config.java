package com.zaakpay;

public class Config {

    public static String ZAAKPAY_SECRET_KEY = "0678056d96914a8583fb518caf42828a" ;

    public static String ENVIRONMENT = "https://zaakstaging.zaakpay.com" ;

    public static String ZAAKPAY_MERCHANT_IDENTIFIER = "b6415a6443604ec59644a70c8b25a0f6" ;

    public static String  TRANSACTION_API_URL = "/api/paymentTransact/V8" ;

    public static String   UPDATE_API_URL = "/updatetransaction" ;

    public static String   TRANSACTION_STATUS_API_URL = "/checkTxn?v=5" ;

    public static String   RETURN_URL = "http://localhost:8080/zaakpay_java_war_exploded/response.jsp" ;


}

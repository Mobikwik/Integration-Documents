# Zaakpay Java Integration Kit

 1. The ZaakPay Java integration kit consists of four files.
	
	- Transaction.java
	  This will generate the request for triggering different Zaakpay's API. 

	- RequestParameters.java
	  This will provide the mandatory/optional request parameters for API request you can skip this by passing
	  all the parameters as function arguments.
	
	- ZaakpayApiRequestParameters.java
	  This will provide the final request parameters for API request including checksum and API url.

	- ChecksumGenerator.java
	  This will generate checksum.

	- Config.java
	  This will provide the configuration for transaction processing/update.

 2. Open Config.py and verify the below values.
	- ENVIRONMENT ( https://zaakstaging.zaakpay.com ( Staging ) or https://api.zaakpay.com ( Production ) )
	- RETURN_URL ( Callback URL on which Zaakpay will send the response , "" will send callback to the default test page of zaakpay for staging environment )


